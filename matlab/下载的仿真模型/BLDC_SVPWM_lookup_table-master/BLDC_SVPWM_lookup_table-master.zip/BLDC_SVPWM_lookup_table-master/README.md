# BLDC_SVPWM_lookup_table
matlab scripts that create sine or SPACE VECTOR (saddle) profiles for BLDC motors and saves them as .txt file.

![space_vector](https://user-images.githubusercontent.com/30388414/64533874-b0c4b980-d314-11e9-9a71-c0ec3c28b21e.png)

# Support the project

This project is part of S-drive BLDC driver and Faze4 Robotic arm projects. 
Those projects are completely Open source and free to all and I would like to keep it that way, so any help in terms of donations or advice is really appreciated. Thank you!

[![Check the arm in action !](https://user-images.githubusercontent.com/30388414/86798915-a036ba00-c071-11ea-824d-4456f2cdf797.png)](https://paypal.me/PCrnjak?locale.x=en_US)
